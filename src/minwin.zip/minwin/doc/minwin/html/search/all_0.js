var searchData=
[
  ['a_0',['a',['../classminwin_1_1Color.html#aa12f3b064fbd81e53ec66288e87b13b4',1,'minwin::Color']]]
];
