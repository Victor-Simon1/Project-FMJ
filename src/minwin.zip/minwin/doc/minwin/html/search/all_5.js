var searchData=
[
  ['g_13',['g',['../classminwin_1_1Color.html#af9658b6eaae3fef9f3f49aad4697926a',1,'minwin::Color']]],
  ['get_5fcolor_14',['get_color',['../classminwin_1_1Text.html#a6665e26311431bdca4cd912cc945dff7',1,'minwin::Text']]],
  ['get_5fdraw_5fcolor_15',['get_draw_color',['../classminwin_1_1Window.html#a917005ed0989dd0fe0912bfd84391b3b',1,'minwin::Window']]],
  ['get_5fheight_16',['get_height',['../classminwin_1_1Window.html#a81a7acd7437d120a48b8a39ab1cbd645',1,'minwin::Window']]],
  ['get_5fposx_17',['get_posX',['../classminwin_1_1Text.html#a244d3b4464e7495dbe63832762b8af67',1,'minwin::Text']]],
  ['get_5fposy_18',['get_posY',['../classminwin_1_1Text.html#a58f1c43dc20bcdd05263cf17425276d1',1,'minwin::Text']]],
  ['get_5fstring_19',['get_string',['../classminwin_1_1Text.html#a2cce6c3260516215afe58d7bb0d14d6f',1,'minwin::Text']]],
  ['get_5ftitle_20',['get_title',['../classminwin_1_1Window.html#ac3c339cfa2aefca007a16ac90ad25f6c',1,'minwin::Window']]],
  ['get_5fwidth_21',['get_width',['../classminwin_1_1Window.html#a9c4efc06a4aed37198a48a67a8beccb0',1,'minwin::Window']]]
];
