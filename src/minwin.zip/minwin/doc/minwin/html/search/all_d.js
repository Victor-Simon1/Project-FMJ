var searchData=
[
  ['set_5fcolor_45',['set_color',['../classminwin_1_1Text.html#af9f87cc2979bd9d7a31a68e6e20c0193',1,'minwin::Text']]],
  ['set_5fdraw_5fcolor_46',['set_draw_color',['../classminwin_1_1Window.html#a84ceb9ce0b62894d87aef7705ee3fdbf',1,'minwin::Window']]],
  ['set_5fheight_47',['set_height',['../classminwin_1_1Window.html#acf1b883bb8e23db99bcbedfc970441f2',1,'minwin::Window']]],
  ['set_5fpos_48',['set_pos',['../classminwin_1_1Text.html#aa48bad2ad7e21d5e4e30032233b23d57',1,'minwin::Text']]],
  ['set_5fposx_49',['set_posX',['../classminwin_1_1Text.html#a636dc70f07a485dc8e1f44fc2d5c2052',1,'minwin::Text']]],
  ['set_5fposy_50',['set_posY',['../classminwin_1_1Text.html#a3d8b34c8527f89f2b1b1b03f9f702ed9',1,'minwin::Text']]],
  ['set_5fstring_51',['set_string',['../classminwin_1_1Text.html#a14233b33feae75406052d26351531a97',1,'minwin::Text']]],
  ['set_5ftitle_52',['set_title',['../classminwin_1_1Window.html#a91ab39662e03ee4f58c7a3e21e9b63fd',1,'minwin::Window']]],
  ['set_5fwidth_53',['set_width',['../classminwin_1_1Window.html#a2d23693029bae06d895c995646abe58a',1,'minwin::Window']]]
];
