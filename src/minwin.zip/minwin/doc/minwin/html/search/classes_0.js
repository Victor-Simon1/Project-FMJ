var searchData=
[
  ['clock_65',['Clock',['../classminwin_1_1Clock.html',1,'minwin']]],
  ['color_66',['Color',['../classminwin_1_1Color.html',1,'minwin']]]
];
