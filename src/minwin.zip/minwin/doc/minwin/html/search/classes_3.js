var searchData=
[
  ['text_71',['Text',['../classminwin_1_1Text.html',1,'minwin']]]
];
