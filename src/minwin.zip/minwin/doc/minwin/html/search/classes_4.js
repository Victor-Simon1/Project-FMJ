var searchData=
[
  ['window_72',['Window',['../classminwin_1_1Window.html',1,'minwin']]]
];
