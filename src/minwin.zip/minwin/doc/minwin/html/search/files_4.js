var searchData=
[
  ['text_2ecpp_82',['text.cpp',['../text_8cpp.html',1,'']]],
  ['text_2eh_83',['text.h',['../text_8h.html',1,'']]]
];
