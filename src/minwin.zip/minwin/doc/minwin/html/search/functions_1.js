var searchData=
[
  ['display_89',['display',['../classminwin_1_1Window.html#afadfafa5a0b9472554759004aafb327e',1,'minwin::Window']]]
];
