var searchData=
[
  ['load_5ffont_99',['load_font',['../classminwin_1_1Window.html#a758d15fdad9e6fd118506da811dad0cc',1,'minwin::Window']]]
];
