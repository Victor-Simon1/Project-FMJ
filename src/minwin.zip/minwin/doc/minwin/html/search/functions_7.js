var searchData=
[
  ['register_5fkey_5fbehavior_107',['register_key_behavior',['../classminwin_1_1Window.html#a5f5f8ab100da9e772742687fe5f6546a',1,'minwin::Window']]],
  ['register_5fquit_5fbehavior_108',['register_quit_behavior',['../classminwin_1_1Window.html#a67d8f182df5491e440fe9d9cdba1252e',1,'minwin::Window']]],
  ['render_5ftext_109',['render_text',['../classminwin_1_1Window.html#abe1de5c4b4f40f8abb5f55f5aa55f0fa',1,'minwin::Window::render_text(int posX, int posY, std::string txt, const Color &amp;) const'],['../classminwin_1_1Window.html#aba95aa2ccf44d07d704f4f91d269404c',1,'minwin::Window::render_text(const Text &amp;txt) const']]],
  ['restart_110',['restart',['../classminwin_1_1Clock.html#a775bf97123b58c768571868341d28b08',1,'minwin::Clock']]]
];
