var searchData=
[
  ['minwin_73',['minwin',['../namespaceminwin.html',1,'']]]
];
